var dns_url='https://h5.speaka.live'
//var dns_url='http://dev.speaka.cn'